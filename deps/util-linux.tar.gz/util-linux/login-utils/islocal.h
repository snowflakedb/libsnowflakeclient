#ifndef UTIL_LINUX_LOGIN_ISLOCAL_H
#define UTIL_LINUX_LOGIN_ISLOCAL_H

extern int is_local(const char *user);

#endif /* UTIL_LINUX_LOGIN_ISLOCAL_H */
